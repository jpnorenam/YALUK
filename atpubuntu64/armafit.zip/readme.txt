
    ARMAFIT - ARMA (z-rational function) / LAPLACE (s-rational function)
              Model Fitting Program

    Version 2.02, May 6, 1997


    ARMAFIT is a frequency-domain linear-system identification program
both for continuous-time systems represented as a rational function of
s (Laplace operator) and for discrete-time systems represented as a
rational function of 1/z (Z-transform operator; ARMA model).  This program
has been applied to frequency-dependent transmission-line modeling,
transformer modeling, reactor modeling by this writer, when he was carrying
out his PhD at Doshisha University, Kyoto, Japan, and also to network-
equivalent studies by Prof. Mustafa Kizilcay of FH Osnabrueck, Germany.
Those projects are for accurate simulations of power systems transients,
but the program may be able to be used for other system identification
problems.  ARMAFIT is first designed especially for a phase-domain
transmission-line model (NODA SETUP) and also for a frequency-dependent
circuit element (KIZILCAY F-DEPENDENT: KFD) of the ATP (Alternative
Transients Program) version of EMTP (ElectroMagnetic Transients Program),
and thus the program can generate coefficient file (punch-out file) to be
used in a subsequent ATP simulation.  But after this writer started working
at CRIEPI (Central Research Institute of Electric Power Industry), Tokyo,
Japan, he has not used ATP.  Because he has not changed the format of
input and output files of ARMAFIT, ARMAFIT can be used for those purpose
as long as the format of the ATP side has not changed.  Now, this writer
maintains ARMAFIT as an independent linear-system identification program.

    For the NODA SETUP use, refer to "User Instructions of Noda Setup in
ATP", which may be distributed by the EEUG (European EMTP Users Group) and
also may be available at an anonymous FTP server ftp://ftp.ee.mtu.edu
maintained by Prof. B.A. Mork of the Michigan Institute of Technology.
As for the KFD use, Prof. Kizilcay will provide a user instructions.

    ARMAFIT reads frequency characteristics of a system such as an
impedance, an admittance, and a transfer function of electrical circuits,
and then fits the characteristics with a rational function of s or 1/z.
The fitting is performed using a numerically stable procedure called
Linearized Least-Squares method developed by this writer, and model order is
determined by use of SD (Standard Deviation) and AIC (Akaike's Information
Criterion).  For theoretical background, consult this writer's PhD thesis of
which the abstract is available at

    http://www02.so-net.or.jp/~noda/phd.html

The above thesis describes the theory used in ARMAFIT in detail.  Briefly
mentioning, ARMAFIT uses a linearized error function in which all coefficients
to be identified are included as linear.  Thus, ARMAFIT always identifies the
optimum solution of the coefficients, unlike conventional nonlinear
optimization methods requiring an iterative procedure which sometimes does not
converge.  In order to solve the normal equation newly derived from the
linearized error function, ARMAFIT uses the Householder transformation avoiding
round-off errors of the normal equation which is inherently ill-conditioned.
Also, ARMAFIT uses relative error rather than absolute error in order to assure
the accuracy for any frequency characteristics.  The order of an identified
model is determined using AIC (Akaike's Information Criterion) in ARMAFIT, and
the identified model is assured to be stable by Routh's method (s-function) or
by Jury's method (z-function).  Those techniques can be found in the references
provided at the end.

    ARMAFIT is a DOS application, but compiled by a 32-bit native compiler,
and thus it does not have the limitation of 640 KB.  In this distribution,
self-documented illustrative examples:

    - sample1s.aft: modeling of the admittance of an LCR circuit
                    with an s-rational function model
    - sample2s.aft: modeling of the admittance of an iron-core reactor
                    with an s-rational function model
    - sample3s.aft: modeling of the voltage-transfer function of a
                    transformer with an s-rational function model
    - sample1z.aft: same as sample1s.aft, but with an ARMA model
    - sample2z.aft: same as sample2s.aft, but with an ARMA model
    - sample3z.aft: same as sample3s.aft, but with an ARMA model

are included.  Type 'ARMAFIT -?' for help.

--
Taku Noda, Taku's Software Archive
South bldg 365, Duo Komae, 2-10-15 Iwado-kita, Komae-shi, Tokyo 201, Japan
URL: http://www02.so-net.or.jp/~noda/
E-mail: noda@ka2.so-net.or.jp


REFERENCES

[1]  T. Noda, N. Nagaoka, and A. Ametani, "Phase Domain Modeling of
     Frequency-Dependent Transmission Lines by Means of an ARMA Model,"
     IEEE Trans., Power Delivery, Vol. 11, No. 1, pp. 401-411, January,
     1996.

[2]  T. Noda, M. Kubota, and N. Nagaoka, "A Phase-Domain Surge Calculation
     Method," Proc. Annual Meeting of IEE of Japan, Paper No. 1387, 1993.

[3]  T. Noda and N. Nagaoka, "A Phase-Domain Surge Calculation Method
     (Part II) - A Surge Calculation on a Cable -," Proc. Kansai-Branch
     Meeting, IEE of Japan, Paper No. G4-31, 1993.

[4]  T. Noda and N. Nagaoka, "A Time-Domain Surge Calculation Method with
     Frequency-Dependent Modal-Transformation Matrices," Conference of
     Electric Power System Technology, IEE of Japan, PE-93-153, 1993.

[5]  T. Noda, N. Nagaoka, and A. Ametani, "Further Improvements to a Phase-
     Domain ARMA Line Model in Terms of Convolution, Steady-State
     Initialization, and Stability," IEEE Power Engineering Society Summer
     Meeting, Denver, Colorado, USA, 1996. (to be published in IEEE Trans.)

[6]  T. Noda and N. Nagaoka, "Development of ARMA Models for a Transient
     Calculation using Linearized Least-Squares Method," Trans. IEE of
     Japan, Vol. 114-B, No. 4, pp. 396-402, 1994.

[7]  T. Noda and N. Nagaoka, "An Estimation Method of Linear Network's
     Transfer Function," Conference of Electric Power System Technology,
     IEE of Japan, PE-92-150, 1992.

[8]  T. Noda and N. Nagaoka, "An Estimation Method of Linear Network's
     Transfer Function," Proc. Kansai-Branch Meeting, IEE of Japan, Paper
     No. G4-8, 1992.

[9]  T. Noda and N. Nagaoka, "A Linearized Least-Squares Method for
     Estimating Linear Network's Transfer Function - Relative Error
     Evaluation -," Proc. Annual Meeting of IEE of Japan, Paper No. 1397,
     1993.

[10] T. Noda, T. Sawada, K. Fujii, and N. Nagaoka, "ARMA Models for
     Transient Calculations and its Identification - Identification of
     Coefficients and Orders -,"  Proc. Annual Meeting of IEE of Japan,
     Paper No. 1373, 1994.

[11] T. Noda, N. Nagaoka, and A. Ametani, "Fault-Surge Calculations using
     the Phase-Domain ARMA Line Model," Trans. IEE of Japan, Vol. 116-B,
     No. 11, pp. 1409-1414, 1996.

[12] J.S. Lim and A.V. Oppenheim, Advanced Topics in Signal Processing,
     Prentice-Hall, 1988. 

[13] E.I. Jury, Theory and Application of the z-Transform Method, Wieley,
     New York, 1964.

[14] L. Weinberg, Network Analysis and Synthesis, McGraw-Hill, 1962.
